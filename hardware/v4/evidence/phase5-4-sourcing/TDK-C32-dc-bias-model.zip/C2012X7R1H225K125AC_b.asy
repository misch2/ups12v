Version 4
SymbolType CELL
LINE Normal -8 16 -8 -16
LINE Normal 8 16 8 -16
LINE Normal -8 0 -64 0
LINE Normal 8 0 64 0
TEXT 0 -32 Center 2 TDK
TEXT 0 32 Center 2 C2012X7R1H225K125AC
TEXT 0 56 Center 2 C=2.2uF
WINDOW 0 -80 -24 Left 2
SYMATTR SpiceModel C2012X7R1H225K125AC_b
SYMATTR Prefix X
SYMATTR ModelFile C2012X7R1H225K125AC_b_LTspice.mod
SYMATTR Description Multilayer Ceramic Chip Capacitor
PIN -64 0 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN 64 0 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
